int ret_4(){
    return 4;
}